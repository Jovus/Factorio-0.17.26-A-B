data:extend({
  {
    type = "recipe",
    name = "blasting-charge",
    energy_required = 8,
    enabled = false,
    category = "crafting",
    ingredients =
    {
      {"explosives", 20},
      {"grenade", 2},
      {"empty-barrel", 1}
    },
    result= "blasting-charge",
    result_count = 1
  }
})