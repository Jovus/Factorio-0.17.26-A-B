require("prototypes.items")
require("prototypes.projectiles")
require("prototypes.recipes")
require("prototypes.technology")

-- data.raw["tile"]["water"].can_be_part_of_blueprint = nil