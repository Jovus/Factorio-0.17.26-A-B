data:extend(
{
   {
    type = "bool-setting",
    name = "angels-enable-icon-scaling-warehouses",
    setting_type = "startup",
    default_value = false,
    order = "a",
   },
}
)


