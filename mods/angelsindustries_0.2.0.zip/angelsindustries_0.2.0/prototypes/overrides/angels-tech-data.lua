--KEY TECHs
angelsmods.functions.add_exception("tech-red-packs")
angelsmods.functions.add_exception("tech-red-labs")
angelsmods.functions.add_exception("tech-green-packs")
angelsmods.functions.add_exception("tech-green-labs")
angelsmods.functions.add_exception("tech-orange-packs")
angelsmods.functions.add_exception("tech-orange-labs")
angelsmods.functions.add_exception("tech-blue-packs")
angelsmods.functions.add_exception("tech-blue-labs")
angelsmods.functions.add_exception("tech-yellow-packs")
angelsmods.functions.add_exception("tech-yellow-labs")

--BASE
angelsmods.functions.add_exception("automation")

--BIO PROCESSING
angelsmods.functions.add_exception("bio-temperate-farming")
angelsmods.functions.add_exception("bio-temperate-farm")
angelsmods.functions.add_exception("bio-desert-farming")
angelsmods.functions.add_exception("bio-desert-farm")
angelsmods.functions.add_exception("bio-swamp-farming")
angelsmods.functions.add_exception("bio-swamp-farm")