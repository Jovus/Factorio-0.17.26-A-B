angelsmods.functions.OV.remove_science_pack("automation", "angels-science-pack-red")
angelsmods.functions.OV.set_science_pack("automation", "angels-science-pack-grey")
