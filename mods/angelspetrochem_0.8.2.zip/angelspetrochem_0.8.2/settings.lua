data:extend(
{
   {
    type = "bool-setting",
    name = "angels-enable-converter",
    setting_type = "startup",
    default_value = true,
    order = "a",
   },
   {
    type = "bool-setting",
    name = "angels-hide-converter",
    setting_type = "startup",
    default_value = true,
    order = "b",
   },
   {
    type = "bool-setting",
    name = "angels-enable-acids",
    setting_type = "startup",
    default_value = true,
    order = "c",
   },
}
)


