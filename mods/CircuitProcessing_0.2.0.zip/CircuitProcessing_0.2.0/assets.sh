#!/bin/bash
FACTORIO=~/factorio17

mkdir -p graphics/icons
convert $FACTORIO/data/base/graphics/icons/processing-unit.png \
    \( -clone 0 -modulate 30,0 \) \
    \( -clone 0 -fill "#AAAAAA" -colorize 100 \) \
    \( -clone 0 -colorspace HSL -channel Hue -separate +colorspace +channel \) \
    \( -clone 2,3 -channel R -separate -compose difference -composite -negate -level 50%,100% \) -delete 2,3 \
    \( -clone 0,1,2 -compose src-over -composite \) -delete 1,2 \
    +swap -compose copy-opacity -composite \
    graphics/icons/advanced-processing-unit.png

for f in speed-module effectivity-module productivity-module; do
  colour=$(convert $FACTORIO/data/base/graphics/icons/$f.png -format '%[pixel:p{25,4}]' info:)
  convert $FACTORIO/data/base/graphics/icons/$f.png -fill $colour -fuzz '15%' \
    -draw 'color 10,10 floodfill'\
    graphics/icons/$f-0.png
  convert -background transparent module-mask.png -alpha copy graphics/icons/$f-0.png \
    -compose multiply -channel RGB -composite \
    -distort SRT 28 \
    graphics/icons/$f-0-harness.png
  for l in "" "-2" "-3"; do
    convert module-mask.png -alpha copy $FACTORIO/data/base/graphics/icons/$f$l.png \
      -compose multiply -channel RGB -composite \
      -distort SRT 28\
      graphics/icons/$f$l-harness.png
  done
done

locales=$(cd $FACTORIO/data/base/locale; echo *)
for locale in $locales; do
  mkdir -p locale/$locale
  echo "[item-name]" > locale/$locale/CircuitProcessing.cfg
  grep 'electronic-circuit=\|advanced-circuit=\|processing-unit=' $FACTORIO/data/base/locale/$locale/* | sed -e 's/^/cp-/' >> locale/$locale/CircuitProcessing.cfg
  if [ -f locale.in/$locale/item-names.cfg ]; then
    cat locale.in/$locale/item-names.cfg >> locale/$locale/CircuitProcessing.cfg
  fi
  if [ -f locale.in/$locale/settings.cfg ]; then
    cat locale.in/$locale/settings.cfg >> locale/$locale/CircuitProcessing.cfg
  fi
done
