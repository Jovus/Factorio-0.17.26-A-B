if mods["aai-industry"] then
	require("science_aai")
end
