if mods["omnimatter_science"] and mods["omnimatter_crystal"] then
    require("science_omni")
end
